package x86;

public class Consts {
	
	public final static boolean SIGNED = true;
	public final static boolean UNSIGNED = false;
	
	public final static byte UNDEF_SIZE = 0;
	public final static byte BYTE = 1;
	public final static byte WORD = 2;
	public final static byte DWORD = 4;
		
	public final static byte REGFILE_SIZE = 8;

	
	//ia32 doubleword-size register index
    public final static byte eax_reg = 0;
    public final static byte ecx_reg = 1;
    public final static byte edx_reg = 2;
    public final static byte ebx_reg = 3;
    public final static byte esp_reg = 4;
    public final static byte ebp_reg = 5;
    public final static byte esi_reg = 6;
    public final static byte edi_reg = 7; 

    //ia32 word-size register index
    public final static byte ax_reg = 0+REGFILE_SIZE*WORD;
    public final static byte cx_reg = 1+REGFILE_SIZE*WORD;
    public final static byte dx_reg = 2+REGFILE_SIZE*WORD;
    public final static byte bx_reg = 3+REGFILE_SIZE*WORD;
    public final static byte sp_reg = 4+REGFILE_SIZE*WORD;
    public final static byte bp_reg = 5+REGFILE_SIZE*WORD;
    public final static byte si_reg = 6+REGFILE_SIZE*WORD;
    public final static byte di_reg = 7+REGFILE_SIZE*WORD; 

    //ia32 byte-size register index
    public final static byte al_reg = 0+REGFILE_SIZE*BYTE;
    public final static byte cl_reg = 1+REGFILE_SIZE*BYTE;
    public final static byte dl_reg = 2+REGFILE_SIZE*BYTE;
    public final static byte bl_reg = 3+REGFILE_SIZE*BYTE;
    public final static byte ah_reg = 4+REGFILE_SIZE*BYTE;
    public final static byte ch_reg = 5+REGFILE_SIZE*BYTE;
    public final static byte dh_reg = 6+REGFILE_SIZE*BYTE;
    public final static byte bh_reg = 7+REGFILE_SIZE*BYTE; 

    //operand kind
	public final static byte REG = 0;
	public final static byte IMM = 1;
	public final static byte MEM = 2;

    //ia32 instruction mode, operandtype_size
    //r register; i immediate; m memory;
    public final static byte TARGET = 0;
    public final static byte i_d = 1;
    public final static byte i_w = 2;
    public final static byte i_b = 3;
    public final static byte r_d = 4;
    public final static byte r_w = 5;
    public final static byte r_b = 6;
    public final static byte m_d = 7;
    public final static byte m_w = 8;
    public final static byte m_b = 9;
    public final static byte rr_d = 10;
    public final static byte rr_w = 11;
    public final static byte rr_b = 12;
    public final static byte ri_d = 13;
    public final static byte ri_w = 14;
    public final static byte ri_b = 15;
    public final static byte mr_d = 16;
    public final static byte mr_w = 17;
    public final static byte mr_b = 18;
    public final static byte rm_d = 19;
    public final static byte rm_w = 20;
    public final static byte rm_b = 21;
    public final static byte mi_d = 22;
    public final static byte mi_w = 23;
    public final static byte mi_b = 24;
    public final static byte rri_d = 25;
    public final static byte rri_w = 26;  
    public final static byte rmi_d = 27;
    public final static byte rmi_w = 28;
    public final static byte rrr_d = 29;
    public final static byte rrr_w = 30;
    public final static byte rrm_d = 31;
    public final static byte rrm_w = 32;

    //memory operand related constants
    //modr/m
    public final static byte MODERM_REG_MEM = 0;
    public final static byte MODERM_REG_DISP8_MEM =1;
    public final static byte MODERM_REG_DISP32_MEM = 2;
    public final static byte MODERM_REG_REG = 3;

    public final static byte SIB_SCALE_1	= 0;
    public final static byte SIB_SCALE_2	= 1;
    public final static byte SIB_SCALE_4	= 2;
    public final static byte SIB_SCALE_8	= 3;

    public final static byte BASE = 0x01;
    public final static byte INDEX = 0x02;
    public final static byte SCALE = 0x04;
    public final static byte DISP = 0x08;

    public final static byte IS_BASE = BASE;
    public final static byte IS_SIB = BASE|INDEX|SCALE;
    public final static byte IS_BASE_DISP = BASE|DISP;
    public final static byte IS_SIB_DISP = IS_SIB|DISP;
    public final static byte IS_DISP = DISP;

	//op_inc, op_dec, op_not, op_neg
	public final static byte NUM_UNIALU_OPS = 4;

    //unary alu kind
    public final static byte op_inc = 0;
    public final static byte op_dec = 1;
    public final static byte op_not = 2;
    public final static byte op_neg = 3;

    //op_add, op_or;op_adc;op_sbb;op_and;op_sub;op_xor;op_cmp;
	public final static byte NUM_BINALU_OPS = 8;

    //binary alu kind
    public final static byte op_add = 0; 
    public final static byte op_or = 1;
    public final static byte op_adc = 2; 
    public final static byte op_sbb = 3; 
    public final static byte op_and = 4; 
    public final static byte op_sub = 5; 
    public final static byte op_xor = 6; 
    public final static byte op_cmp = 7;
   
    //mul/div kind
    public final static byte op_mul = 1; 
    public final static byte op_imul = 2;
    public final static byte op_div = 3;
    public final static byte op_idiv = 4;
    
    //prefixes
    public final static byte es_prefix = 0x26;
    public final static byte cs_prefix = 0x2E;
    public final static byte ss_prefix = 0x36;
    public final static byte ds_prefix = 0x3E;
    public final static byte fs_prefix = 0x64;
    public final static byte gs_prefix = 0x65;
    

    public final static byte opnd_size_prefix = 0x66;
    public final static byte addr_mode_prefix = 0x67;

    public final static byte lock_prefix = (byte)0xF0;
    public final static byte repnz_prefix = (byte)0xF2;
    public final static byte repz_prefix = (byte)0xF3; 
    public final static byte rep_prefix = (byte)0xF3;

    public final static byte cc_ult = 0x72; 
    public final static byte cc_uge = 0x73;
    public final static byte cc_eq =  0x74;
    public final static byte cc_ne =  0x75; 
    public final static byte cc_ule = 0x76; 
    public final static byte cc_ugt = 0x77; 
    public final static byte cc_lz  = 0x78; 
    public final static byte cc_gez = 0x79;
    public final static byte cc_p  =  0x7a; 
    public final static byte cc_np =  0x7b;
    public final static byte cc_lt =  0x7c; 
    public final static byte cc_ge =  0x7d; 
    public final static byte cc_le =  0x7e; 
    public final static byte cc_gt =  0x7f;
       
}
