package x86;

public class MemOpnd extends Opnd{
    byte scale;
    RegOpnd index;
    RegOpnd base;
    ImmOpnd disp;
    byte form;
    
    public MemOpnd(byte s, RegOpnd i, RegOpnd b, ImmOpnd d){
    	scale = s;
    	index = i;
    	base = b;
    	disp = d;

    	if( base != null ){
    		form = IS_BASE;
    		if(index != null){
    			form = IS_SIB;
	    		if( disp != null){
	    			form = IS_SIB_DISP;
	    		}
    		}else if( disp!=null ){
    			form = IS_BASE_DISP;
    		}
    	}else if( disp != null ){
    		form = IS_DISP;
    	}
    	    	
    	kind = MEM;
    	
    }

    public MemOpnd(byte s, RegOpnd i, RegOpnd b, ImmOpnd d, byte sz){
        this(s, i, b, d);
        size = sz;
    }
}
