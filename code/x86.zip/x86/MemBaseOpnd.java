package x86;

public class MemBaseOpnd extends MemOpnd{
	public MemBaseOpnd(RegOpnd b){
		super((byte)0, null, b, null);
	}
}
