package x86;

public class Test {

	public static void main(String[] a){
		
		Emitter e = new Emitter();
		
		RegOpnd i = new RegOpnd(Consts.ebx_reg);
		RegOpnd b = new RegOpnd(Consts.eax_reg);
		
		e.mov( new MemOpnd((byte)0,null,b,null), new RegOpnd(Consts.eax_reg));
		e.mov( new MemOpnd((byte)0,i,b,null), new RegOpnd(Consts.al_reg));
		e.add( new MemOpnd((byte)0,null,b,null), new RegOpnd(Consts.ax_reg));
	}
}
