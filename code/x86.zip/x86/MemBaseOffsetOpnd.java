package x86;

public class MemBaseOffsetOpnd extends MemOpnd{
	public MemBaseOffsetOpnd(RegOpnd b, ImmOpnd d){
		super((byte)0, null, b, d);
	}
}
