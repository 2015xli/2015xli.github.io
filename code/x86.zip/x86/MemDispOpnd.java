package x86;

public class MemDispOpnd extends MemOpnd {
	public MemDispOpnd(ImmOpnd i){
		super((byte)0, null, null, i);
	}
}
