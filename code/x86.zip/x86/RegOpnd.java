package x86;

public class RegOpnd extends Opnd{
	byte regno;  //the internal no of the reg, e.g., eax = ax = al in regno
	byte regname; //the name of the reg, e.g. eax != ax != al in regname
	public RegOpnd(byte r){
		regname = r;
		regno = (byte)(r%REGFILE_SIZE);
		
		size = (byte)(r/REGFILE_SIZE);		
		if(size==0) size = Consts.DWORD;
		else if(size==1) size = Consts.BYTE;
		else if(size==2) size = Consts.WORD;
		else Emitter.error();
			
		kind = REG;
	}
}
