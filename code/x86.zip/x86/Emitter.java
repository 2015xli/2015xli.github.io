package x86;

public class Emitter extends Consts{
	byte[] buf;
	int pos;
	
	public Emitter(){
		buf = new byte[50];
		pos = 0;
	}

	public static void error(){
		error(null);
	}
	public static void error(String info){
		if(info == null)
			System.out.println("Incorrect X86 emitter");

		System.out.println(info);
	}

	public byte[] codeBuf(){
		byte[] code = new byte[pos];
		System.arraycopy(buf, 0, code, 0, pos);
		return code;
	}

	public int codeLength(){
		return pos;
	}
	
	public int patch(int patchOffset, int value, byte size){
		int old = 0;
		switch(size){
		case DWORD:
			old = buf[patchOffset+3]&0xf;
			old = old<<8 + buf[patchOffset+2]&0xf;
			buf[patchOffset+3] = (byte)(value>>24);			
			buf[patchOffset+2] = (byte)(value>>16);			
		case WORD:
			old = old<<8 + buf[patchOffset+1]&0xff;
			buf[patchOffset+1] = (byte)(value>>8);
		case BYTE:
			old = old<<8 + buf[patchOffset]&0xff;
			buf[patchOffset] = (byte)(value); break;
		default: error();
		}
		return old;
	}

	static class UnialuBits{
	    byte opcode;
	    byte b_bits;
	    byte d_bits;
	    byte r_bits;  
	    UnialuBits(byte o, byte b, byte d, byte r){
	    	
	    }
	}

	static class BinaluBits{
		byte opcode;

		byte mr_b_bits;
		byte mr_d_bits;

		byte rm_b_bits;
		byte rm_d_bits;

	    byte al_bits;
		byte eax_bits;   
		BinaluBits(){super();}
		BinaluBits(byte op,byte mrb, byte mrd, byte rmb, byte rmd, byte al, byte eax){
		    opcode = op;
		    mr_b_bits = mrb; 
		    mr_d_bits = mrd; 
		    rm_b_bits = rmb; 
		    rm_d_bits = rmd; 
		    al_bits = al;   
		    eax_bits = eax;  
		}
	}
	
	static UnialuBits[] unialu_bits = new UnialuBits[NUM_UNIALU_OPS];
	static BinaluBits[] binalu_bits = new BinaluBits[NUM_BINALU_OPS];
	static {
		unialu_bits[0] = new UnialuBits(op_inc, (byte)0xFE, (byte)0xFF, (byte)0x40);
		unialu_bits[1] = new UnialuBits(op_dec, (byte)0xFE, (byte)0xFF, (byte)0x48);
		unialu_bits[2] = new UnialuBits(op_not, (byte)0xF6, (byte)0xF7, (byte)0);   
		unialu_bits[3] = new UnialuBits(op_neg, (byte)0xF6, (byte)0xF7, (byte)0);   
		
		binalu_bits[0] = new BinaluBits(op_add, (byte)0,(byte)1,(byte)2,(byte)3,(byte)4,(byte)5); 
	    for(byte i=1; i< NUM_BINALU_OPS; i++ ){
	        byte delta = (byte)(NUM_BINALU_OPS*i);
	        binalu_bits[i] = new BinaluBits();
		    binalu_bits[i].opcode = i;
		    binalu_bits[i].al_bits   = (byte)(binalu_bits[0].al_bits + delta);  
		    binalu_bits[i].eax_bits  = (byte)(binalu_bits[0].eax_bits + delta); 
		    binalu_bits[i].mr_b_bits = (byte)(binalu_bits[0].mr_b_bits + delta);
		    binalu_bits[i].mr_d_bits = (byte)(binalu_bits[0].mr_d_bits + delta);
		    binalu_bits[i].rm_b_bits = (byte)(binalu_bits[0].rm_b_bits + delta);
		    binalu_bits[i].rm_d_bits = (byte)(binalu_bits[0].rm_d_bits + delta);
	    }
	}
	
	void checkBufferSize(){
		if( pos+8 <= buf.length )
			return;
		byte[] newbuf = new byte[pos*2];
		System.arraycopy(buf, 0, newbuf, 0, pos);
		buf = newbuf;
		return;
	}
			
	/* To form the SIB byte 
	 * the byte contains  scale index  base
	 *                    [7 6][5 4 3][2 1 0]
	 */
	byte sib_byte(byte scale, byte index, byte base)
	{
	  return (byte)(((scale&0x3)<<6)|((index&0x7)<<3)|(base&0x7));
	}

	/* To form the MODR/M byte 
	 * the byte cotains  mod   reg/op   r/m 
	 *                  [7 6] [5 4 3] [2 1 0]
	 */
	byte modrm_byte(byte mod, byte regop, byte rm)
	{
	  return (byte)(((mod&0x3)<<6)|((regop&0x7)<<3)|(rm&0x7));
	}

	byte opndSize(Opnd opnd){
		
		if(opnd.size() != UNDEF_SIZE ) return opnd.size();
		
		if(opnd.kind() == IMM){
			ImmOpnd immo = (ImmOpnd)opnd;
			if(immo.imm < 128 || immo.imm >= -128){ return BYTE;}
			if(immo.imm < 32768 || immo.imm >= -32768){ return WORD;}
		}
		return DWORD;
	}
		
	void imm_encoding(int imm, byte size){
	    switch(size){
        case BYTE:
            buf[pos++] = (byte)imm;
            break;
 
        case DWORD:
        	buf[pos++] = (byte)imm;
        	buf[pos++] = (byte)(imm>>8);
        	buf[pos++] = (byte)(imm>>16);
        	buf[pos++] = (byte)(imm>>24);
            break;
        
        case WORD:
        	buf[pos++] = (byte)imm;
        	buf[pos++] = (byte)(imm>>8);
            break;
        default: error();
      
        }
	    
		return;
	}

	void imm_encoding(ImmOpnd immo, byte size){
		if(immo.size() != UNDEF_SIZE)
			if(immo.size() != size ) error();

		imm_encoding(immo.imm, size);
	}
	
	void imm_encoding(ImmOpnd immo){
		imm_encoding(immo.imm, immo.size());
	}
	
	void mem_encoding(MemOpnd memo, byte regop){
	    switch(memo.form){
	        case IS_BASE:
	            if(memo.base.regno==ebp_reg){
	                buf[pos++]=modrm_byte(MODERM_REG_DISP8_MEM,regop,ebp_reg);
	                buf[pos++]=0;
	                return;
	            }else if(memo.base.regno==esp_reg){
	                buf[pos++]=modrm_byte(MODERM_REG_MEM,regop,esp_reg);
	                buf[pos++]=sib_byte(SIB_SCALE_1,esp_reg,esp_reg);
	                return;    
	            }
	            buf[pos++]=modrm_byte(MODERM_REG_MEM,regop,memo.base.regno);
	            return;
	
	        case IS_SIB:
	            if(memo.base.regno==ebp_reg)  {
	                buf[pos++]=modrm_byte(MODERM_REG_DISP8_MEM,regop,esp_reg);
	                buf[pos++]=sib_byte(memo.scale,memo.index.regno,memo.base.regno);
	                buf[pos++]=0;
	                return;
	            }
	            buf[pos++]=modrm_byte(MODERM_REG_MEM,regop,esp_reg);
	            buf[pos++]=sib_byte(memo.scale,memo.index.regno,memo.base.regno);
	            return;
	
	        case IS_BASE_DISP:
	            if(memo.disp.size()== BYTE ||
	            		( (memo.disp.size()== UNDEF_SIZE) &&(memo.disp.imm>=-128)&&(memo.disp.imm<=127))){
	                buf[pos++]=modrm_byte(MODERM_REG_DISP8_MEM,regop,memo.base.regno);
	                if(memo.base.regno==esp_reg){
	                    buf[pos++]=sib_byte(SIB_SCALE_1,esp_reg,esp_reg);
	                }
	                imm_encoding(memo.disp.imm, BYTE);
	            }else{
	                buf[pos++]=modrm_byte(MODERM_REG_DISP32_MEM,regop,memo.base.regno);
	                if(memo.base.regno==esp_reg){
	                    buf[pos++]=sib_byte(SIB_SCALE_1,esp_reg,esp_reg);
	                }
	                imm_encoding(memo.disp.imm, DWORD);
	            }
	            return;
	                
	        case IS_SIB_DISP:
	            if(memo.disp.size()== BYTE ||
	            		( (memo.disp.size()== UNDEF_SIZE) &&(memo.disp.imm>=-128)&&(memo.disp.imm<=127))){
	                buf[pos++]=modrm_byte(MODERM_REG_DISP8_MEM,regop,esp_reg);
	                buf[pos++]=sib_byte(memo.scale,memo.index.regno,memo.base.regno);
	                imm_encoding(memo.disp.imm, BYTE);
	            }else{
	                buf[pos++]=modrm_byte(MODERM_REG_DISP32_MEM,regop,esp_reg);
	                buf[pos++]=sib_byte(memo.scale,memo.index.regno,memo.base.regno);
	                imm_encoding(memo.disp.imm, DWORD);
	            }
	            return;
	        
	        case IS_DISP:
	            buf[pos++]=modrm_byte(MODERM_REG_REG,regop,ebp_reg);
	            imm_encoding(memo.disp.imm, DWORD);
	            return;
	    }
	    error();
	    return;		
	}

	void reg_encoding(byte regno, byte regop)
	{
		buf[pos++] = modrm_byte(MODERM_REG_REG, regop, regno);
		return;
	}
	
	void rmopnd_encoding(Opnd opnd, byte regop)
	{       
	    switch(opnd.kind()){
	    case REG:
	        	RegOpnd rego = (RegOpnd)opnd;
	            reg_encoding( rego.regno, regop);
	            break;
	    case MEM:  
	        	MemOpnd memo = (MemOpnd)opnd;
	            mem_encoding(memo, regop);
	            break;
	    default: error();
	    }    
	    return;
	}		

	///////////////////////////////unified APIs not supposed to be used directly///////////
	void binalu(byte binalu_op, Opnd o1, Opnd o2)
	{
		checkBufferSize();
		BinaluBits alu = binalu_bits[binalu_op];
		
		MemOpnd memo = null;
		RegOpnd rego1 = null;
		RegOpnd rego2 = null;
		ImmOpnd immo = null;

		switch(o1.kind()){
		case MEM:	memo = (MemOpnd)o1;	break;
		case REG:	rego1 = (RegOpnd)o1;break;
		default: error();
		}
		switch(o2.kind()){
		case IMM:	immo = (ImmOpnd)o2;	break;
		case MEM:	memo = (MemOpnd)o2;	break;
		case REG:	rego2 = (RegOpnd)o2;break;
		default: error();
		}		
		
		byte size = o1.size();
		if(size == UNDEF_SIZE)	size = o2.size();
		if(size == UNDEF_SIZE)	size = DWORD; //DWORD is always the default
		
		if(size == WORD) buf[pos++] = opnd_size_prefix;
		
	     //Here we give eax-imm operation higher priority, but this might be not
	     //always good. When the imm is shorted than 8 bits, the rm-imm8 encoding
	     //gives a shorter instruction. The reason is eax-imm always encodes imm 
	     //as 32 bits, no matter if it is shorter than 8 bits or not. 
	        //need improvement... done!
		switch(o2.kind()){
		case IMM:
			if(o1.kind()==REG && rego1.regno == eax_reg &&  //this is common case
					!( size == DWORD && opndSize(immo) != DWORD ) //this is for shorter length
			){
				if(size == BYTE) buf[pos++] = alu.al_bits;
				else{
					buf[pos++] = alu.eax_bits;
				}
			}else{
				if(size == BYTE){
					buf[pos++] = (byte)0x80;
				}else{
					if(opndSize(immo) == BYTE){
			        	buf[pos++] = (byte)0x83; 
			        	size = BYTE;
			        }else{ 
			        	buf[pos++] = (byte)0x81;
			        }
				} 
	        	rmopnd_encoding(o1, alu.opcode);
			}
        	imm_encoding(immo, size);
        	break;
		case REG:
			if(size == BYTE) buf[pos++]=alu.mr_b_bits;
			else buf[pos++]=alu.mr_d_bits;
	        rmopnd_encoding(memo, rego2.regno);
	        break;
		case MEM:
			 if( size == BYTE) buf[pos++]=alu.rm_b_bits;
			 else buf[pos++]=alu.rm_d_bits;
		     mem_encoding(memo, rego1.regno );
		     break;
		default: error();	
		}
		
		return;
	}
	
	void branch(byte condcode, ImmOpnd target)
	{
		checkBufferSize();

		//target is relative offset to next inst
		// it is the absolute address - current addr - inst length
		//inst length is 2 for byte branch, 6 for dword branch
		byte size = target.size();
		if(size == UNDEF_SIZE){
			if((target.imm>=-128)&&(target.imm<=127)) size = BYTE;
			else if((target.imm>=-32768)&&(target.imm<=32767)) size = WORD;
			else size = DWORD;
		}

		if(size == WORD) buf[pos++] = opnd_size_prefix;
		switch(size){		
	        case BYTE:
	            buf[pos++] = condcode;
	            buf[pos++] = (byte)target.imm;
	            break;
	        case WORD: case DWORD:
	            buf[pos++] = 0x0f;
	            buf[pos++] = (byte)(condcode+0x10);
	            imm_encoding(target);
	            break;
	        default: error();
	    }
	    return;
	}

	void movx( RegOpnd reg1, Opnd o2, boolean is_signed)
	{
		checkBufferSize();
		
		if(reg1.size() <= o2.size()) error();
		byte opcode = (byte)(is_signed? 0xBE:0xB6);
		
		if(reg1.size()==WORD) buf[pos++] = opnd_size_prefix;
		if(o2.size()==WORD) opcode++;

		buf[pos++] = 0x0F;
	    buf[pos++] = opcode;
	    rmopnd_encoding(o2, reg1.regno);
	    return;
	}

	void muldiv( byte mdkind, Opnd o1)
	{
		checkBufferSize();
		byte opcode = (byte)(mdkind+4);

		byte size = opndSize(o1);
		if( size == WORD) buf[pos++] = opnd_size_prefix;
		if(size == BYTE)	buf[pos++] = (byte)0xf6;
		else buf[pos++] = (byte)0xf7;
	    rmopnd_encoding(o1, opcode);

	    return;
	}


	void unialu(byte unialu_op, Opnd o1)
	{
		checkBufferSize();
		byte size = o1.size();
		
		UnialuBits alu = unialu_bits[unialu_op];
		
		if( size == UNDEF_SIZE ) size = DWORD;
		if( size == WORD) buf[pos++] = opnd_size_prefix;
		
		if( (alu.opcode == op_inc) || (alu.opcode == op_dec) ){
		    if( o1.kind() == REG ){
	            buf[pos++] = (byte)(alu.r_bits + ((RegOpnd)o1).regno);
		    	return;
		    }
		}
		
		if( size == DWORD || size == WORD ) buf[pos++] = alu.d_bits; 
		else buf[pos++] = alu.b_bits; 
	
		rmopnd_encoding(o1, alu.opcode);
		return;
	}
	
	////////////Interfaces below/////////////////////////////////////////////////
	//The size argument in the interfaces should be removed soon.              //
	//Sometimes we need the size argument, e.g., "mov [eax], 10" is ambiguous  //
	//if without size info, since we dont know if it is a byte/word/dword move.//
	//Another case is "inc [eax]", which doesnt tell if it is byte/word/dword. //  
	/////////////////////////////////////////////////////////////////////////////
	
	public void nop()
	{
		checkBufferSize();
		buf[pos++] = (byte)0x90;
		return;
	}

	public void prefix(byte pfx){
		checkBufferSize();
	    buf[pos++] = pfx;
	    return;
	}
	
	/* mov instruction */
	public void mov(Opnd o1, Opnd o2){
		checkBufferSize();
		
		RegOpnd rego1 = null;
		RegOpnd rego2 = null;
		ImmOpnd immo = null;
		MemOpnd memo = null;
		
		switch(o1.kind()){
		case MEM: memo = (MemOpnd)o1; break;
		case REG: rego1 = (RegOpnd)o1; break;
		default: error();
		}
			
		switch(o2.kind()){
		case IMM: immo = (ImmOpnd)o2; break;
		case MEM: memo = (MemOpnd)o2; break;
		case REG: rego2 = (RegOpnd)o2; break;
		default: error();
		}		
		
		byte size = o1.size();
		if(size == UNDEF_SIZE)	size = o2.size();
		if(size == UNDEF_SIZE)	size = DWORD; //DWORD is always the default

		if(size == WORD) buf[pos++] = opnd_size_prefix; 

		switch(o2.kind()){
		case REG:
            if(rego2.regno == eax_reg && o1.kind() == MEM && memo.form == IS_DISP ){
            	if(rego2.size() == BYTE) buf[pos++] = (byte)0xa2;
            	else  buf[pos++] = (byte)0xa3;
            	imm_encoding(memo.disp, rego2.size());
            }else{
            	if(rego2.size() == BYTE) buf[pos++] = (byte)0x88;
            	else buf[pos++] = (byte)0x89;
                rmopnd_encoding(o1, rego2.regno);
            }
            break; 
		case IMM:
			if(o1.kind() == REG){
				if(rego1.size() == BYTE) buf[pos++] = (byte)(0xb0 + (rego1.regno&0x7));
				else buf[pos++] = (byte)(0xb8 + (rego1.regno&0x7));
			}else if(o1.kind() == MEM){
				if(memo.size() == BYTE) buf[pos++] = (byte)0xc6;
				else buf[pos++] = (byte)0xc7;
				mem_encoding(memo, (byte)0);
			}
			imm_encoding(immo, size);
			break;
		case MEM:
			if(o1.kind() != REG) error();
			if(rego1.regno == eax_reg && memo.form == IS_DISP){
				if(rego1.size() == BYTE) buf[pos++] = (byte)0xa0;
				else buf[pos++] = (byte)0xa1;
				imm_encoding(memo.disp, size);
			}else{
				if(rego1.size() == BYTE) buf[pos++] = (byte)0x8a;
				else buf[pos++] = (byte)0x8b;
				mem_encoding(memo, rego1.regno );
			}
			break;
		default: error();
		}
		return;
	}
	
	public void lea( RegOpnd rego1, Opnd o2)
	{
		checkBufferSize();

		if(rego1.size() == BYTE) error();
		if(rego1.size() == WORD) buf[pos++]=opnd_size_prefix;
        buf[pos++] = (byte)0x8d;
        mem_encoding( (MemOpnd)o2, rego1.regno);
	}

	public void push(Opnd o1)
	{
		checkBufferSize();
		if(o1.size() == WORD) buf[pos++]=opnd_size_prefix;
	    switch(o1.kind()){
	        case REG: 
	            buf[pos++] = (byte)(0x50 + ((RegOpnd)o1).regno);
	            break;
	        case MEM: 
	            buf[pos++] = (byte)0xFF;
	            mem_encoding((MemOpnd)o1, (byte)6);
	            break;
	        case IMM:
	        	if(o1.size() == BYTE) buf[pos++] = 0x6a;
	        	else buf[pos++] = 0x68;
	            imm_encoding((ImmOpnd)o1);
	            break;
	        default: error();
	    }
	    return;
	}

	public void pop(Opnd o1)
	{
		checkBufferSize();
		if(o1.size() == BYTE) error();
		if(o1.size() == WORD) buf[pos++]=opnd_size_prefix;

		switch(o1.kind()){
	        case REG:
	            buf[pos++] = (byte)(0x58 + ((RegOpnd)o1).regno);
	            break;
	        case MEM:
	            buf[pos++] = (byte)0x8F;
	            break;
	        
	        default: error();
	    }
	    return;
	}
	
	public void leave(byte size) 
	{
		checkBufferSize();

	    switch(size){
	    case WORD:  buf[pos++] = opnd_size_prefix;
	    case DWORD:	buf[pos++] =(byte)0xc9; break;
	    default: error();
	    } 
	    
		return;
	}

	public void leave(){ leave(DWORD); }
	
	public void ret(ImmOpnd imm ) 
	{
		checkBufferSize();

		if( imm == null )
            buf[pos++] = (byte)0xc3;
		else{
        	if(imm.size()!= UNDEF_SIZE && imm.size()!=WORD) error();
            buf[pos++] = (byte)0xc2;
            imm_encoding(imm);
	    }
	    return;
	}

	public void ret(){
		ret(null);
	}	
	public void call(Opnd target)
	{
		checkBufferSize();
		
		if( target.size()==WORD ) buf[pos++] = opnd_size_prefix;
		
		switch(target.kind()){
			//target has relative offset to next inst
	        //Note: 
			//if target is an absolute address, transform it into relative offset
			//using target addr - current addr - 5, (5 is the call inst length)
	        //sometimes absolute address is easy when generate code to call a function pointer
	        //but need to guarantee the correctness when codebuf is copied
	        //an easier solution is to put the function pointer into a reg/mem for calling
	        //this solution is actually necessary for PIC code generation
	        case IMM: 
	            buf[pos++] = (byte)0xE8;
	            imm_encoding(((ImmOpnd)target));
	            break;
	        case MEM: case REG: 	        //target has absolute indirect address 
	            buf[pos++] = (byte)0xFF;
	            rmopnd_encoding(target, (byte)2);
	            break;
	        default: error();
	    }
	    return;
	}
	
	public void jmp(Opnd target)
	{
		checkBufferSize();

		byte size = opndSize(target);
		if(size == WORD) buf[pos++] = opnd_size_prefix;
		
		//imm target is relative offset to next inst
		// it is  "absolute address - current addr - inst length"
		//inst length is 2 for byte branch, 5 for dword branch
		// r m target is absolute indirect address
		if(target.kind() == IMM){
			if( size == BYTE ) buf[pos++] = (byte)0xEB;
			else buf[pos++] = (byte)0xE9;
			imm_encoding(((ImmOpnd)target), size);
		}else{
            buf[pos++] = (byte)0xFF;
            rmopnd_encoding(target, (byte)4);
	    }
	    return;
	}

	public void test(Opnd o1, Opnd o2)
	{
		checkBufferSize();
		byte size = o1.size();
		if(size == WORD) buf[pos++] = opnd_size_prefix;
		
		RegOpnd rego1 = null, rego2 = null;
		ImmOpnd immo = null;
		switch(o1.kind()){
		case MEM: 	break;
		case REG:	rego1 = (RegOpnd)o1;	break;
		default: error();
		}
			
		switch(o2.kind()){
		case IMM:	immo = (ImmOpnd)o2;	break;
		case MEM:	break;
		case REG:	rego2 = (RegOpnd)o2;	break;
		default: error();
		}	
		
		switch(o2.kind()){	
		case IMM: 
			if(rego1.regno == eax_reg){
				if( size == BYTE )	buf[pos++] = (byte)0xa8;
				else	buf[pos++] = (byte)0xa9;
				imm_encoding(immo);
				break;
			} 
			
			if(size == BYTE)	buf[pos++] = (byte)0xf6;
			else		buf[pos++] = (byte)0xf7;
			rmopnd_encoding(o1, (byte)0);
			imm_encoding(immo);
			break;
		case REG:
			if(size == BYTE)	buf[pos++] = (byte)0x84;
			else	buf[pos++] = (byte)0x85;
			rmopnd_encoding(o1, rego2.regno);
			break;
		default: error();
		}
	}

	public void add(Opnd o1, Opnd o2){	binalu(op_add, o1, o2);	}
	public void or(Opnd o1, Opnd o2){	binalu(op_or, o1, o2);	}
	public void adc(Opnd o1, Opnd o2){	binalu(op_adc, o1, o2);	}
	public void sbb(Opnd o1, Opnd o2){	binalu(op_sbb, o1, o2);	}
	public void and(Opnd o1, Opnd o2){	binalu(op_and, o1, o2);	}
	public void sub(Opnd o1, Opnd o2){	binalu(op_sub, o1, o2);	}
	public void xor(Opnd o1, Opnd o2){	binalu(op_xor, o1, o2);	}
	public void cmp(Opnd o1, Opnd o2){	binalu(op_cmp, o1, o2);	}

	public void movzx( RegOpnd reg1, Opnd o2){	movx(reg1, o2, false);	}
	public void movsx( RegOpnd reg1, Opnd o2){	movx(reg1, o2, true);	}

	public void jc(ImmOpnd target){	branch(cc_ult, target);	}
	public void jb(ImmOpnd target){	branch(cc_ult, target);	}
	public void jnae(ImmOpnd target){	branch(cc_ult, target);	}
	public void jae(ImmOpnd target){	branch(cc_uge, target);	}
	public void jnb(ImmOpnd target){	branch(cc_uge, target);	}
	public void jnc(ImmOpnd target){	branch(cc_uge, target);	}
	public void je(ImmOpnd target){		branch(cc_eq, target);	}
	public void jz(ImmOpnd target){		branch(cc_eq, target);	}
	public void jne(ImmOpnd target){	branch(cc_ne, target);	}
	public void jnz(ImmOpnd target){	branch(cc_ne, target);	}
	public void jbe(ImmOpnd target){	branch(cc_ule, target);	}
	public void jna(ImmOpnd target){	branch(cc_ule, target);	}
	public void ja(ImmOpnd target){	branch(cc_ugt, target);	}
	public void jnbe(ImmOpnd target){	branch(cc_ugt, target);	}
	public void js(ImmOpnd target){		branch(cc_lz, target);	}
	public void jns(ImmOpnd target){	branch(cc_gez, target);	}
	public void jp(ImmOpnd target){	branch(cc_p, target);	}
	public void jpe(ImmOpnd target){	branch(cc_p, target);	}
	public void jnp(ImmOpnd target){	branch(cc_np, target);	}
	public void jpo(ImmOpnd target){	branch(cc_np, target);	}
	public void jl(ImmOpnd target){	branch(cc_lt, target);	}
	public void jnge(ImmOpnd target){	branch(cc_lt, target);	}
	public void jge(ImmOpnd target){	branch(cc_ge, target);	}
	public void jnl(ImmOpnd target){	branch(cc_ge, target);	}
	public void jle(ImmOpnd target){	branch(cc_le, target);	}
	public void jng(ImmOpnd target){	branch(cc_le, target);	}
	public void jgt(ImmOpnd target){	branch(cc_gt, target);	}
	public void jnle(ImmOpnd target){	branch(cc_gt, target);	}

	public void inc(Opnd o1){ unialu(op_inc, o1);	}
	public void dec(Opnd o1){ unialu(op_dec, o1);	}
	public void not(Opnd o1){ unialu(op_not, o1);	}
	public void neg(Opnd o1){ unialu(op_neg, o1);	}
	
	public void mul(Opnd o1){ muldiv(op_mul, o1);}
	public void imul(Opnd o1){ muldiv(op_imul, o1);}
	public void div(Opnd o1){ muldiv(op_div, o1);}
	public void idiv(Opnd o1){ muldiv(op_idiv, o1);}

	public void imul( RegOpnd rego1, Opnd o2) 
	{
		imul(rego1, rego1, o2);
	}
	
	public void imul( RegOpnd rego1, Opnd o2, Opnd o3)
	{ 
		checkBufferSize();
		byte size = rego1.size();
		
		if(size == WORD) buf[pos++]=opnd_size_prefix;
		
		if(o3.kind() == IMM){
			if( opndSize(o3) == BYTE ){ buf[pos++]=0x6b; size = BYTE; }
			else buf[pos++]=0x69;
            rmopnd_encoding( o2, rego1.regno);
            imm_encoding((ImmOpnd)o3, size);
		}else{
            buf[pos++] = 0x0F;
            buf[pos++] = (byte)0xAF;
            rmopnd_encoding(o3, ((RegOpnd)o2).regno);			
		}
		
	    return;
	}

}
	