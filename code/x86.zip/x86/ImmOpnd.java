package x86;

public class ImmOpnd extends Opnd{
	int imm;
	
	public ImmOpnd(int i){
		imm = i;
		kind = IMM;
	}

	public ImmOpnd(int i, byte s){
		imm = i;
		kind = IMM;
		size = s;
	}
}
