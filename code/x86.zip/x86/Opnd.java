package x86;

public class Opnd extends Consts{
	protected byte size;
	protected byte kind;
	
	byte size(){
		return size;
	}
	
	byte kind(){
		return kind;
	}
}


