package elf;

import java.io.PrintStream;

import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;

public class StrSection extends Section{
	public String table;
	
	private HashSet stringPool;
	private HashMap stringMap;
	
	//for parsing
	StrSection(Entity e){
		super(e);
	}
	
	//for linking
	StrSection(String s, int type){
		super(s, type);
		stringPool = new HashSet(); 
	}

	public int specialize(){
		table = new String(data); 
		
		if(entity.fhdr.e_shstrndx == secno){
			entity.shstrtab = this;
		}
			
		return 0;
	}
	
	public int dump(PrintStream out){
		out.println("\nString Table: " + name);
		out.println(table);
		return 0;
	}
	
	//a simplistic way to generate string table
	public void addString(String s){
		if(s.equals("")) return;
		
		stringPool.add(s); 
		return;
	}
		
	public int indexString(String s){
		if(table == null) Util.error("String table not exists");
		
		Integer index = (Integer)stringMap.get(s);
		if(index==null) return 0;
		
		return index.intValue();
		
	}

	public int buildIndex(){
		
		if(table != null) Util.error("String table exists");	
		
		StringBuffer tabbuf = new StringBuffer();
		
		stringMap = new HashMap();
		
		int index = 0;
		Iterator si = stringPool.iterator();
		while(si.hasNext()){
			tabbuf.append('\0');
			index++;
			String s = (String)si.next();
			tabbuf.append(s);
			stringMap.put(s, new Integer(index));
			index = tabbuf.length();
		}
		tabbuf.append('\0');
		table = new String(tabbuf);
		
		return 0;
	}
	
	public int link(){
		data = table.getBytes();
		size = data.length;
		return 0;
	}
}
