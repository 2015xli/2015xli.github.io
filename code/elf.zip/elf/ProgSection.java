package elf;

public class ProgSection extends Section{

	ProgSection(Entity e){
		super(e);
	}

	ProgSection(String s, int type){
		super(s, type);
	}
	
	public int link(){
		if(data == null )
			size = 0;
		else
			size = data.length;
		
		return 0;
	}
}
