package elf;

import x86.Consts;
import x86.Emitter;
import x86.MemOpnd;
import x86.MemBaseOpnd;
import x86.MemBaseOffsetOpnd;
import x86.RegOpnd;
import x86.ImmOpnd;
/*
extern int flag;
int data=1;
char *info="Hello";
int common;
char zero;
short false = 0;
void greet(char* string)
{
	zero = info[0];
	if(flag){
		data = false;
		hello(string);
	}
	if(common!=1){
		common=1;
		hello(info);
		hello("\nCommon!\n");
	}
}

*/
public class Test_GOT {
	public static void main(String args[]){
		
		////////////////parsing//////////////
		Loader loader = new Loader();
		
		Entity entity = loader.load("greet.o");

		entity.dump(System.out);
		
		///////////////linking///////////////
		entity = new Entity("greet.c");
		entity.isSEndian = true;
		
		//all sections (except shstrtab) are generated before other things to ease the cross-reference 
		ProgSection text = new ProgSection(".text", SectHeader.SHT_PROGBITS);
		ProgSection data = new ProgSection(".data", SectHeader.SHT_PROGBITS);
		ProgSection rodata = new ProgSection(".rodata", SectHeader.SHT_PROGBITS);
		ProgSection datarel = new ProgSection(".data.rel.local", SectHeader.SHT_PROGBITS);
		Section bss = new Section(".bss", SectHeader.SHT_NOBITS);
		StrSection strtab = new StrSection(".strtab", SectHeader.SHT_STRTAB);
		SymSection symtab = new SymSection(".symtab", SectHeader.SHT_SYMTAB, strtab);
		RelSection reltext = new RelSection(".rel.text", SectHeader.SHT_REL, symtab, text);
		RelSection reldatarel = new RelSection(".rel.data.rel.local", SectHeader.SHT_REL, symtab, datarel);
	
		//these flags are actually predefined by the ELF spec
		text.setHeaderFlags(SectHeader.SHF_ALLOC | SectHeader.SHF_EXECINSTR);
		data.setHeaderFlags(SectHeader.SHF_ALLOC | SectHeader.SHF_WRITE);
		bss.setHeaderFlags(SectHeader.SHF_ALLOC | SectHeader.SHF_WRITE);
		datarel.setHeaderFlags(SectHeader.SHF_ALLOC | SectHeader.SHF_WRITE);
		rodata.setHeaderFlags(SectHeader.SHF_ALLOC);
		
		SectionList sectList = new SectionList(entity);
		sectList.addSection(text);
		sectList.addSection(data);
		sectList.addSection(datarel);
		sectList.addSection(bss);
		sectList.addSection(rodata);
		sectList.addSection(strtab);
		sectList.addSection(symtab);
		sectList.addSection(reltext);
		sectList.addSection(reldatarel);
		sectList.buildShstrtab();
		//principly, the sectList cant be changed
		
		//prepare the strtab first, since symtab will reference it
		strtab.addString("greet.c");
		strtab.addString("data");
		strtab.addString("info");
		strtab.addString("false");
		strtab.addString("greet");
		strtab.addString("_GLOBAL_OFFSET_TABLE_");
		strtab.addString("zero");
		strtab.addString("flag");
		strtab.addString("hello");
		strtab.addString("common");
		strtab.buildIndex(); //strTab is only ready afer packed, so that the string is indexible
		//principly, strTab is readonly thereafter
		
		//prepare the symtab second, symbols will be referenced next
		//the symbol for the defined func is delayed till the code is generated, so the length is known
		//symtab.addGlobalSym("greet", 0, text.data.length, SymSection.STT_FUNC, text.secno);
		SymSection.SymEntry symData = symtab.addGlobalSym("data", 0, 4, SymSection.STT_OBJECT, data.secno);
		SymSection.SymEntry symInfo = symtab.addGlobalSym("info", 0, 4, SymSection.STT_OBJECT, datarel.secno);
		SymSection.SymEntry symFalse= symtab.addGlobalSym("false", 0, 2, SymSection.STT_OBJECT, bss.secno);
		SymSection.SymEntry symZero = symtab.addGlobalSym("zero", 1, 1, SymSection.STT_OBJECT, SectHeader.SHN_COMMON);
		SymSection.SymEntry symCommon = symtab.addGlobalSym("common", 4, 4, SymSection.STT_OBJECT, SectHeader.SHN_COMMON);

		SymSection.SymEntry symGOT = symtab.addGlobalSym("_GLOBAL_OFFSET_TABLE_", 0, 0, SymSection.STT_NOTYPE, SectHeader.SHN_UNDEF);;
		SymSection.SymEntry symHello = symtab.addGlobalSym("hello", 0, 0, SymSection.STT_NOTYPE, SectHeader.SHN_UNDEF);
		SymSection.SymEntry symFlag = symtab.addGlobalSym("flag", 0, 0, SymSection.STT_NOTYPE, SectHeader.SHN_UNDEF);
		symtab.buildTable(); //build the local syms: section, sym1: Filename, and sym0
		//principly, symTab is readonly thereafter
		
		SymSection.SymEntry symRodata = symtab.getSectionSym(rodata);

		//next to populate the sections
		
		//we dont need to populate data/datarel sections, since they are populated
		//in the symbol generation operation. But we temporarily populate them here
		data.data = new byte[4]; //for symbol data
		Util.writeWord(data.data, 0, 1, true);
		
		datarel.data = new byte[4]; //for symbol info, its value is filled in 
									//by link editor according to relocation, 
									//which is pointed to rodata symbol
		Util.writeWord(datarel.data, 0, 0, true); //this is unnecessary
						
		//lets build the rel.data.rel.local section for info
		reldatarel.addRelocation(0, symRodata, RelSection.R_386_32);

		//populate rodata section
		rodata.data =  ("hello"+'\0'+"\nCommon!\n").getBytes();

		//bss has no data, but has size for symbol zero
		bss.setSectionSize(2);
		
		//generate codes for text section
		Emitter e = new Emitter();
		
		RegOpnd ebp = new RegOpnd(Consts.ebp_reg);
		RegOpnd esp = new RegOpnd(Consts.esp_reg);
		RegOpnd edx = new RegOpnd(Consts.edx_reg);
		RegOpnd ebx = new RegOpnd(Consts.ebx_reg);
		RegOpnd eax = new RegOpnd(Consts.eax_reg);
		RegOpnd ax = new RegOpnd(Consts.ax_reg);
		RegOpnd dl = new RegOpnd(Consts.dl_reg);
		ImmOpnd dword_0 = new ImmOpnd(0, Consts.DWORD);
		ImmOpnd byte_0 = new ImmOpnd(0, Consts.BYTE);
		MemOpnd _0_BASE_ebx = new MemBaseOffsetOpnd(ebx, dword_0);
		MemOpnd _BASE_eax = new MemBaseOpnd(eax);
		
		//the size argument of the APIs below should be removed
		//setup stack frame
		e.push(ebp);
		e.mov(ebp, esp);
		e.push(ebx);
		e.sub(esp, new ImmOpnd(4));
		
		//setup GOT value
		e.call(dword_0);
		e.pop(ebx);
		e.add(ebx, new ImmOpnd(3, Consts.DWORD));
			reltext.addRelocation(e.codeLength()-4, symGOT, RelSection.R_386_GOTPC);
			
		//access info[0] in GOT (info in datarel)
		e.mov(eax, _0_BASE_ebx);
			reltext.addRelocation(e.codeLength()-4, symInfo, RelSection.R_386_GOT32);
		
		e.mov(eax, _BASE_eax);
		e.mov(dl, _BASE_eax);
		e.mov(eax, _0_BASE_ebx);
			reltext.addRelocation(e.codeLength()-4, symZero, RelSection.R_386_GOT32);
			
		e.mov(_BASE_eax, dl);
		e.mov(eax, _0_BASE_ebx);
			reltext.addRelocation(e.codeLength()-4, symFlag, RelSection.R_386_GOT32);

		e.mov(eax, _BASE_eax);
		e.test(eax, eax); 
		e.je(new ImmOpnd(0));
		int patchOffset = e.codeLength() - 1;

		e.mov(eax, _0_BASE_ebx);
			reltext.addRelocation(e.codeLength()-4, symFalse, RelSection.R_386_GOT32);

		e.mov(ax, _BASE_eax);
		e.movsx(edx, ax);
		e.mov(eax, _0_BASE_ebx);
			reltext.addRelocation(e.codeLength()-4, symData, RelSection.R_386_GOT32);

		e.mov(_BASE_eax, edx);
		e.sub(esp, new ImmOpnd(12));
		e.push(new MemOpnd((byte)0, null, ebp, new ImmOpnd(8)));
		e.call(new ImmOpnd(-4, Consts.DWORD));
			reltext.addRelocation(e.codeLength()-4, symHello, RelSection.R_386_PLT32);

		e.add(esp, new ImmOpnd(16));
			e.patch(patchOffset, e.codeLength() - patchOffset - 1, Consts.BYTE);

		e.mov(eax, _0_BASE_ebx);
			reltext.addRelocation(e.codeLength()-4, symCommon, RelSection.R_386_GOT32);

		e.mov(eax, _BASE_eax);
		e.cmp(eax, new ImmOpnd(1)); //
		e.je(byte_0);
		patchOffset = e.codeLength() - 1;
		
		e.mov(eax, _0_BASE_ebx);
			reltext.addRelocation(e.codeLength()-4, symCommon, RelSection.R_386_GOT32);

		e.mov(_BASE_eax, new ImmOpnd(1, Consts.DWORD));
		e.mov(eax, _0_BASE_ebx);
			reltext.addRelocation(e.codeLength()-4, symInfo, RelSection.R_386_GOT32);
		
		e.mov(eax, _BASE_eax);
		e.sub(esp, new ImmOpnd(12));
		e.push(eax);
		e.call(new ImmOpnd(-4, Consts.DWORD));
			reltext.addRelocation(e.codeLength()-4, symHello, RelSection.R_386_PLT32);

		e.add(esp, new ImmOpnd(0x10));
		e.sub(esp, new ImmOpnd(0xc));
		e.lea(eax, new MemBaseOffsetOpnd(ebx, new ImmOpnd(6, Consts.DWORD))); //
			reltext.addRelocation(e.codeLength()-4, symRodata, RelSection.R_386_GOTOFF);

		e.push(eax);
		e.call(new ImmOpnd(-4, Consts.DWORD));
			reltext.addRelocation(e.codeLength()-4, symHello, RelSection.R_386_PLT32);

		e.add(esp, new ImmOpnd(0x10));
			e.patch(patchOffset, e.codeLength() - patchOffset - 1, Consts.BYTE);
		e.mov(ebx, new MemOpnd((byte)0, null, ebp, new ImmOpnd(-4)));
		e.leave();
		e.ret();
		text.data = e.codeBuf();

		//now ready to build this function symbol with size available
		symtab.addGlobalSym("greet", 0, text.data.length, SymSection.STT_FUNC, text.secno);
				
		//all the sections are populated, now set the properties for section header
		rodata.setHeaderAlign(1);
		text.setHeaderAlign(4);
		
		entity.fhdr = new FileHeader(entity, 
				(byte)FileHeader.ELFCLASS32, 
				(byte)FileHeader.ELFDATA2LSB, 
				(short)FileHeader.ET_REL, 
				(short)FileHeader.EM_386,
				0 /* e_flags */); 
		
		entity.link();
		entity.serialize();
		
		entity.dump(System.out);
		
		Util.outputFilefromBuffer("world.o", entity.buffer);
		
	};
}
