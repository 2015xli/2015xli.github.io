package elf;

import java.io.PrintStream;
import java.util.Iterator;

public class Entity {
	String name;
	byte[] buffer;
	int pos;
	boolean isSEndian;
	
	FileHeader fhdr;
	PrgHdrList phdrs;
	SecHdrList shdrs;
	SectionList sects;

	//quick accessors
	/*
	public SymSection dynsymtab;
	public SymSection symtab;
	*/
	public StrSection shstrtab;
	
	
	Entity(String n){
		name = n;
	}
		
	public int parse(){
		
		if(buffer == null){
			Util.error("File open incorrect");
			return -1;
		}
		
		fhdr = new FileHeader(this);
		int res = fhdr.parse();
		if( res == -1 ){
			Util.error("File Header incorrect");
			return -1;
		}
		
		phdrs = new PrgHdrList(this);
		res = phdrs.parse();
		if( res == -1 ){
			Util.error("Program Headers incorrect");
			return -1;
		}
		
		shdrs = new SecHdrList(this);
		res = shdrs.parse();
		if( res == -1 ){
			Util.error("Section Headers incorrect");
			return -1;
		}
		
		sects = new SectionList(this);
		res = sects.parse();
		if( res == -1 ){
			Util.error("Section Contents incorrect");
			return -1;
		}

		return res;
	}
	
	public SectHeader getSectHeader(int secno){
		if(secno >= 0 && secno < fhdr.e_shnum)
			return shdrs.shdr[secno];

		Util.error("section header index incorrect");
		return null;
	}

	public Section getSection(int secno){
		if(secno >= 0 && secno < fhdr.e_shnum)
			return (Section)(sects.sectList.get(secno));

		Util.error("section index incorrect");
		return null;
	}

	public String getSymbolName(int symSectIndex, int symIndex){
		int tabIndex = ((SectHeader)(getSectHeader(symSectIndex))).sh_link;
		int strIndex = getSymEntry(symSectIndex, symIndex).st_name;
		return getString( tabIndex, strIndex );
	}
	
	public SymSection.SymEntry getSymEntry(int symSectIndex, int symIndex){
		return (SymSection.SymEntry)((SymSection)getSection(symSectIndex)).symbolList.get(symIndex);
	}

	public String getSectionNameString(int sectIndex){
		return getString( shstrtab.secno, shdrs.shdr[sectIndex].sh_name);
	}

	public int getSectionCount(){
		return sects.sectList.size();
	}
	
	public String getSectionName(int sectIndex){
		return ((Section)(sects.sectList.get(sectIndex))).name;
	}

	public String getString(int tabIndex, int strIndex){
				
		StrSection sect = (StrSection)sects.sectList.get(tabIndex);
		
		if(sect == null ){ 
			Util.error("strtab section incorrect");
			return null;
		}
					
		if(strIndex <0 || strIndex >= sect.table.length()){ 
			Util.error("Index into strtab incorrect");
			return null;
		}
		if(sect.table.charAt(strIndex)== 0)
			return null;
		
		int end = sect.table.indexOf(0,strIndex);
		return sect.table.substring(strIndex, end);
		
	}
	
	public void dump(PrintStream out){
		
		if(phdrs == null ){
			out.println("\nNo Program Header");
		}else{
			phdrs.dump(out);
		}
		
		shdrs.dump(out);

		Iterator si = sects.sectList.iterator();
		while(si.hasNext()){
			Section sect = (Section)si.next();
			sect.dump(out);
		}
		return;
	}

	//////////////////////////////////////linking related/////////////
	
	public void checkBufferSize(int estSize){
		if(buffer == null ) Util.error("ELF linker error");
		if( pos + estSize < buffer.length )
			return;
		byte[] newbuf = new byte[pos + estSize*2];
		System.arraycopy(buffer, 0, newbuf, 0, pos);
		buffer = newbuf;
		return;
	}
			
	public int link(){
		//linking computes the values for integrity and cross-reference
		// for example the phoff shoff phnum shnum, and section and symbol indices
		
		fhdr.link();
		if(phdrs != null)
			phdrs.link();
		
		sects.link();
		
		shdrs = new SecHdrList(this);
		shdrs.link();
		
		return 0;
	}
	
	public int serialize(){

		buffer = new byte[1024];
		pos = 0;
		
		fhdr.serialize();
		if(phdrs != null)
			phdrs.serialize();
		
		shdrs.serialize();
		sects.serialize();
		
		return 0;
	}

}
