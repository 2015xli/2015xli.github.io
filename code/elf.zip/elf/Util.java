package elf;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Util {
	static void error(){
		System.out.println("Util operation error");		
		return;
	}

	static void error(String s){
		System.out.println(s);		
		return;
	}
	
	public static byte readByte(byte[] buf, int pos){
		return buf[pos];
	}

	public static short readShort(byte[] buf, int pos, boolean smallendian){
		if(!smallendian){
			error();
			return -1;
		}
		return (short)((buf[pos++]&0xff)|(buf[pos]<<8));
	}

	public static int readWord(byte[] buf, int pos, boolean smallendian){
		if(!smallendian){
			error();
			return -1;
		}
		return ((buf[pos++]&0xff)|
				((buf[pos++]<<8)&0xff00)|
				((buf[pos++]<<16)&0xff0000)|
				((buf[pos++]<<24)));
	}

	public static int writeByte(byte[] buf, int pos, byte val){
		buf[pos++] = val;
		return pos;
	}

	public static int writeShort(byte[] buf, int pos, short val, boolean smallendian){
		if(!smallendian){
			error();
		}
		buf[pos++] = (byte)val;
		buf[pos++] = (byte)(val >> 8);
		return pos;
	}

	public static int writeWord(byte[] buf, int pos, int val, boolean smallendian){
		if(!smallendian){
			error();
		}
		buf[pos++] = (byte)val;
		buf[pos++] = (byte)(val >> 8);
		buf[pos++] = (byte)(val >> 16);
		buf[pos++] = (byte)(val >> 24);
		return pos;
	}
	
	public static byte[] loadFileintoBuffer(String pathname){
		File file = new File(pathname);
		FileInputStream input;
		
		try{
			input = new FileInputStream(file);
		}catch(Exception exc){
			return null;
		}

		
		byte[] buffer = new byte[(int)file.length()];
		
		try{
			int len = buffer.length;
			int offset = 0;
			int n = 0;
			while( offset < len && n>=0){
				
				n = input.read(buffer, offset, len-offset);
				offset += n;
			}
			input.close();
		}catch(Exception e){
			return null;
		} 
		return buffer;
	}
	

	public static int outputFilefromBuffer(String objname, byte[] buf){
	    File file = new File(objname);
		try {	    
	        boolean ok = file.createNewFile();
	        if ( ok==false ) {
	            error(objname + " already exists!");
	            return -1;
	        }
	    
	        FileOutputStream output = new FileOutputStream(file);
	        output.write(buf, 0, buf.length);
	        output.close();
	        
	    } catch (Exception e) {
	    	return -1;
	    }
	    
		return 0;
	}
}
