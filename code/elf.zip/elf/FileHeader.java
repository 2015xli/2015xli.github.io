package elf;

public class FileHeader{
	Entity entity;
	FileHeader(Entity e){
		entity = e;
	}
	public final static int EI_NIDENT = 16;

	public  byte[] e_ident = new byte[EI_NIDENT];
	public short e_type;
	public short e_machine;
	public int e_version;
	public Address e_entry;
	public int e_phoff;
	public int e_shoff;
	public int e_flags;
	public short e_ehsize;
	public short e_phentsize;
	public short e_phnum;
	public short e_shentsize;
	public short e_shnum;
	public short e_shstrndx;
	
	public static int headerSize = 52;
	
	public static final int EI_MAG0 = 0; //File identification
	public static final int EI_MAG1 = 1; //File identification
	public static final int EI_MAG2 = 2; //File identification
	public static final int EI_MAG3 = 3; //File identification
	public static final int EI_CLASS = 4; //File class
	public static final int EI_DATA = 5; //Data encoding
	public static final int EI_VERSION = 6; //File version
	public static final int EI_PAD = 7; //Start of padding bytes
	
	public static final int ET_NONE = 0; //No file type
	public static final int ET_REL = 1; //Relocatable file
	public static final int ET_EXEC = 2; //Executable file
	public static final int ET_DYN = 3; //Shared object file
	public static final int ET_CORE = 4; //Core file
	public static final int ET_LOPROC = 0xff00; //Processor-specific
	public static final int ET_HIPROC = 0xffff; //Processor-specific
	
	public static final int EM_NONE = 0; //No machine
	public static final int EM_M32 = 1; //AT&T WE 32100
	public static final int EM_SPARC = 2; //SPARC
	public static final int EM_386 = 3; //Intel Architecture
	public static final int EM_68K = 4; //Motorola 68000
	public static final int EM_88K = 5; //Motorola 88000
	public static final int EM_860 = 7; //Intel 80860
	public static final int EM_MIPS = 8; //MIPS RS3000 Big-Endian
	public static final int EM_MIPS_RS4_BE = 10; //MIPS RS4000 Big-Endian
	//public static final int RESERVED 11-16 Reserved for future use
	
	public static final byte ELFMAG0 = 0x7f; //e_ident[EI_MAG0]
	public static final byte ELFMAG1 = 'E'; //e_ident[EI_MAG1]
	public static final byte ELFMAG2 = 'L'; //e_ident[EI_MAG2]
	public static final byte ELFMAG3 = 'F'; //e_ident[EI_MAG3]
	
	public static final int ELFCLASSNONE = 0; //Invalid class
	public static final int ELFCLASS32 = 1; //32-bit objects
	public static final int ELFCLASS64 = 2; //64-bit objects
	
	public static final int ELFDATANONE = 0; //Invalid data encoding
	public static final int ELFDATA2LSB = 1; //small endian
	public static final int ELFDATA2MSB = 2; //big endian

	public static final int EV_NONE = 0; //Invalid versionn
	public static final int EV_CURRENT = 1; //Current version 
	
	int parse(){
		byte[] buffer = entity.buffer;
		if (buffer[EI_MAG0] != ELFMAG0 ||
				buffer[EI_MAG1] != ELFMAG1 || 
				buffer[EI_MAG2] != ELFMAG2 ||
				buffer[EI_MAG3] != ELFMAG3){
			System.out.println("Not ELF file");
			return -1;
		}
		
		if(buffer[EI_CLASS] != ELFCLASS32 ){
			System.out.println("Not 32-bit file");
			return -1;
		}
		entity.isSEndian = (buffer[EI_DATA]==ELFDATA2LSB);
		int pos = EI_NIDENT;
		e_type = Util.readShort(buffer, pos, entity.isSEndian); pos+=2;
		e_machine = Util.readShort(buffer, pos, entity.isSEndian); pos+=2;
		e_version = Util.readWord(buffer, pos, entity.isSEndian); pos+=4;
		int entry = Util.readWord(buffer, pos, entity.isSEndian); pos+=4;
		e_entry = new Address(entry);
		e_phoff = Util.readWord(buffer, pos, entity.isSEndian); pos+=4;
		e_shoff = Util.readWord(buffer, pos, entity.isSEndian); pos+=4;
		e_flags = Util.readWord(buffer, pos, entity.isSEndian); pos+=4;
		e_ehsize = Util.readShort(buffer, pos, entity.isSEndian); pos+=2;
		e_phentsize = Util.readShort(buffer, pos, entity.isSEndian); pos+=2;
		e_phnum = Util.readShort(buffer, pos, entity.isSEndian); pos+=2;
		e_shentsize = Util.readShort(buffer, pos, entity.isSEndian); pos+=2;
		e_shnum = Util.readShort(buffer, pos, entity.isSEndian); pos+=2;
		e_shstrndx = Util.readShort(buffer, pos, entity.isSEndian);
		
		entity.pos = FileHeader.headerSize;
		return 0;
	}
	
	FileHeader(Entity e, 
			byte datasize, 
			byte endian, 
			short etype, 
			short emachine, 
			int eflags){
		 entity = e;
		 e_ident[EI_MAG0] = ELFMAG0; 			    
		 e_ident[EI_MAG1] = ELFMAG1;   
		 e_ident[EI_MAG2] = ELFMAG2;   
	     e_ident[EI_MAG3] = ELFMAG3;   
		 e_ident[EI_CLASS] = datasize;
		 e_ident[EI_DATA] = endian;    
		 e_ident[EI_VERSION] = EV_CURRENT;
	
 		 e_type = etype;   
		 e_machine = emachine; 
		 e_version = EV_CURRENT; 
		 e_entry = null;   
		 e_phoff = 0;   
		 e_shoff = 0;   
		 e_flags = eflags;   
		 e_ehsize = 0;  
		 e_phentsize = 0;
		 e_phnum = 0;   
		 e_shentsize = 0;
		 e_shnum = 0;   
		 e_shstrndx = 0;
	}
	
	public int link(){
		
		if(entity.phdrs != null && entity.phdrs.empty != true){
			e_phnum = (short)entity.phdrs.phdr.length; 
			e_phentsize = (short)PrgHdrList.headerSize;
			e_phoff = FileHeader.headerSize;
		}  
		
		//now to build file header
		e_shoff = FileHeader.headerSize + e_phentsize * e_phnum;
		e_shnum = (short)entity.sects.sectList.size();
		e_shstrndx = (short)entity.shstrtab.secno;
		e_shentsize = (short)SectHeader.headerSize;
		e_ehsize = (short)FileHeader.headerSize;

		return 0;
	}
	
	public int serialize( ){
		entity.checkBufferSize(headerSize);
		
		byte[] buffer = entity.buffer;
		System.arraycopy(e_ident, 0, buffer, 0, EI_NIDENT);
		int pos = EI_NIDENT;
		pos = Util.writeShort(buffer, pos, e_type, entity.isSEndian);            
		pos = Util.writeShort(buffer, pos, e_machine, entity.isSEndian);   
		pos = Util.writeWord(buffer, pos, e_version, entity.isSEndian);    
		int entry = e_entry == null? 0: e_entry.value();                                         
		pos = Util.writeWord(buffer, pos, entry, entity.isSEndian);        
		pos = Util.writeWord(buffer, pos, e_phoff, entity.isSEndian);            
		pos = Util.writeWord(buffer, pos, e_shoff, entity.isSEndian);       
		pos = Util.writeWord(buffer, pos, e_flags, entity.isSEndian);      
		pos = Util.writeShort(buffer, pos, e_ehsize, entity.isSEndian);                         
		pos = Util.writeShort(buffer, pos, e_phentsize, entity.isSEndian);
		pos = Util.writeShort(buffer, pos, e_phnum, entity.isSEndian);     
		pos = Util.writeShort(buffer, pos, e_shentsize, entity.isSEndian); 
		pos = Util.writeShort(buffer, pos, e_shnum, entity.isSEndian);     
		pos = Util.writeShort(buffer, pos, e_shstrndx, entity.isSEndian); 

		entity.pos = pos;
		
		
		return 0;
	}
}

