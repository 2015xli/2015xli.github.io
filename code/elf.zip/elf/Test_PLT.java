package elf;

import x86.Consts;
import x86.Emitter;
import x86.MemOpnd;
import x86.RegOpnd;
import x86.ImmOpnd;
/*
void greet(char* string)
{
	hello(string);
}
*/
public class Test_PLT {
	public static void main(String args[]){
		
		////////////////parsing//////////////
		Loader loader = new Loader();
		
		Entity entity = loader.load("greet.o");

		entity.dump(System.out);
		
		///////////////linking///////////////
		entity = new Entity("greet.c");
		entity.isSEndian = true;
		
		//all sections (except shstrtab) are generated before other things to ease the cross-reference 
		ProgSection text = new ProgSection(".text", SectHeader.SHT_PROGBITS);
		ProgSection data = new ProgSection(".data", SectHeader.SHT_PROGBITS);
		StrSection strtab = new StrSection(".strtab", SectHeader.SHT_STRTAB);
		SymSection symtab = new SymSection(".symtab", SectHeader.SHT_SYMTAB, strtab);
		RelSection reltext = new RelSection(".rel.text", SectHeader.SHT_REL, symtab, text);
		
		text.setHeaderFlags(SectHeader.SHF_ALLOC | SectHeader.SHF_EXECINSTR);
		data.setHeaderFlags(SectHeader.SHF_ALLOC | SectHeader.SHF_WRITE);
		
		SectionList sectList = new SectionList(entity);
		sectList.addSection(text);
		sectList.addSection(data);
		sectList.addSection(strtab);
		sectList.addSection(symtab);
		sectList.addSection(reltext);
		sectList.buildShstrtab();
		//principly, the sectList cant be changed
		
		//generate codes for text section
		Emitter e = new Emitter();
		
		RegOpnd ebp = new RegOpnd(Consts.ebp_reg);
		RegOpnd esp = new RegOpnd(Consts.esp_reg);
		RegOpnd ebx = new RegOpnd(Consts.ebx_reg);
		
		//the size argument of the APIs below should be removed
		//setup stack frame
		e.push(ebp);
		e.mov(ebp, esp);
		e.push(ebx);
		e.sub(esp, new ImmOpnd(4));
		//setup GOT value
		e.call(new ImmOpnd(0));
		e.pop(ebx);
		e.add(ebx, new ImmOpnd(3, Consts.DWORD));
		int reloff1 = e.codeLength() - 4; 
		//issue a call into PLT
		e.sub(esp, new ImmOpnd(12));
		e.push(new MemOpnd((byte)0, null, ebp, new ImmOpnd(8)));
		e.call(new ImmOpnd(-4));
		int reloff2 = e.codeLength() - 4;
		//quit the stack and GOT
		e.add(esp, new ImmOpnd(16));
		e.mov(ebx, new MemOpnd((byte)0, null, ebp, new ImmOpnd(-4)));
		e.leave();
		e.ret();
		text.data = e.codeBuf();

		//prepare the strtab first, since symtab will reference it
		strtab.addString("greet.c");
		strtab.addString("greet");
		strtab.addString("_GLOBAL_OFFSET_TABLE_");
		strtab.addString("hello");
		strtab.buildIndex(); //strTab is only ready afer packed, so that the string is indexible
		//principly, strTab is readonly thereafter
		
		//prepare the symtab second, symbols will be referenced next
		symtab.pushLocalSym(null, 0, 0, SymSection.STT_SECTION, text.secno);
		symtab.pushLocalSym(null, 0, 0, SymSection.STT_SECTION, data.secno);

		symtab.addGlobalSym("greet", 0, text.data.length, SymSection.STT_FUNC, text.secno);
		SymSection.SymEntry symGOT = symtab.addGlobalSym("_GLOBAL_OFFSET_TABLE_", 0, 0, SymSection.STT_NOTYPE, SectHeader.SHN_UNDEF);;
		SymSection.SymEntry symCall = symtab.addGlobalSym("hello", 0, 0, SymSection.STT_NOTYPE, SectHeader.SHN_UNDEF);
		symtab.buildTable();
		//principly, symTab is readonly thereafter
		
		//generate the relocations in the text
		RelSection.RelEntry rel1 = reltext.new RelEntry();
		rel1.r_offset = reloff1;
		rel1.r_info = (symtab.symIndex(symGOT) << 8) + (RelSection.R_386_GOTPC & 0xf);
		reltext.relList.add(rel1);

		RelSection.RelEntry rel2 = reltext.new RelEntry();
		rel2.r_offset = reloff2;
		rel2.r_info = (symtab.symIndex(symCall) << 8) + (RelSection.R_386_PLT32 & 0xf);;
		reltext.relList.add(rel2);
		
		entity.fhdr = new FileHeader(entity, 
				(byte)FileHeader.ELFCLASS32, 
				(byte)FileHeader.ELFDATA2LSB, 
				(short)FileHeader.ET_REL, 
				(short)FileHeader.EM_386,
				0 /* e_flags */); 
		
		entity.link();
		entity.serialize();
		
		entity.dump(System.out);
		
		Util.outputFilefromBuffer("world.o", entity.buffer);
		
	};
}
