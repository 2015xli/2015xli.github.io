package elf;

import java.util.LinkedList;
import java.util.Iterator;
import java.io.PrintStream;

public class SymSection extends Section{

	public LinkedList symbolList; //<SymEntry>
	
	public StrSection strTab; //the strtab for symbol name, for linking sh_link
	int numLocals = 0; //number of locals. In symtab, locals stay before others
	
	public static int SymEntrySize = 16;
		
	SymSection(Entity e){
		super(e);
	}

	SymSection(String s, int type, StrSection nameStrtab){
		super(s, type);
		
		symbolList = new LinkedList();
		
		strTab = nameStrtab;
	}

	class SymEntry {
		public int st_name;     	// Elf32_Word st_name;
		public Address st_value;    // Elf32_Addr st_value; 
		public int st_size;     	// Elf32_Word st_size;  
		byte st_info; 			 	// unsigned char st_info;
		byte st_other; 				// unsigned char st_other;
		public short st_shndx;   	// Elf32_Half st_shndx; 
	}	
	
	//ELF32_ST_BIND
	public static final int STB_LOCAL = 0;  
	public static final int STB_GLOBAL = 1; 
	public static final int STB_WEAK = 2;   
	public static final int STB_LOPROC = 13;
	public static final int STB_HIPROC = 15;

	//ELF32_ST_TYPE
	public static final int STT_NOTYPE = 0;
	public static final int STT_OBJECT = 1;
	public static final int STT_FUNC = 2;
	public static final int STT_SECTION = 3;
	public static final int STT_FILE = 4;
	public static final int STT_LOPROC = 13;
	public static final int STT_HIPROC = 15;
	
	public int specialize(){
		SectHeader shdr = entity.getSectHeader(secno);
		int entries = shdr.sh_size/shdr.sh_entsize;
		
		LinkedList symList = new LinkedList();
		
		boolean endian = entity.isSEndian;
		int pos = 0;
		
		for(int j=0; j<entries; j++){
			SymEntry sym = new SymEntry();	
			sym.st_name = Util.readWord(data, pos, endian); pos+=4;     
			int value = Util.readWord(data, pos, endian); pos+=4;   
			sym.st_value = new Address(value);
			sym.st_size = Util.readWord(data, pos, endian); pos+=4;
			sym.st_info = Util.readByte(data, pos); pos++;
			sym.st_other = Util.readByte(data, pos); pos++;
			sym.st_shndx = Util.readShort(data, pos, endian); pos+=2;
			
			symList.add(sym);
		}
		
		symbolList = symList;
		
		return 0;
	}
	
	public int dump(PrintStream out){
		
		out.println("\nSymbol Table: " + name);
		Iterator si = symbolList.iterator();

		int j=0;
		while(si.hasNext()){
			out.print("symbol " + j + " ");
			name = entity.getSymbolName( secno, j);

			if(name == null) name = " ";
			out.println(name);
			
			si.next();
			j++;
		}
		return 0;
	}
	
	/////////////////////////////////////////////
	public int getHeaderLink(){	return strTab.secno;}
	public int getHeaderInfo(){ return numLocals;	}
	public int getEntSize(){return SymEntrySize; }

	public int pushLocalSym(String name, 
			int value, int size, int type, int sectno)
	{
		SymEntry symbol = new SymEntry();
		symbol.st_name = strTab.indexString(name);
		symbol.st_value = new Address(value);
		symbol.st_size = size;
		symbol.st_info = (byte)((STB_LOCAL << 4) + (type & 0xf));
		symbol.st_shndx = (short)sectno;
		
		symbolList.addFirst(symbol);
		numLocals++;
		return 0;
	}
	
	public SymEntry addGlobalSym(String name, 
			int value, int size, int type, int sectno)
	{
		SymEntry symbol = new SymEntry();
		symbol.st_name = strTab.indexString(name);
		symbol.st_value = new Address(value);
		symbol.st_size = size;
		symbol.st_info = (byte)((STB_GLOBAL << 4) + (type & 0xf));
		symbol.st_shndx = (short)sectno;
		
		symbolList.addLast(symbol); //put at the tail so that locals at at front
		
		return symbol;
	}
	
	public int symIndex(SymEntry sym){
		return symbolList.indexOf(sym);
	}

	public int buildTable(){
		
		Iterator si = entity.sects.sectList.iterator();
		while(si.hasNext()){
			Section sect = (Section)si.next();
			if(sect.sh_type == SectHeader.SHT_PROGBITS || 
					sect.sh_type == SectHeader.SHT_NOBITS){
				pushLocalSym(null, 0, 0, STT_SECTION, sect.secno);				
			}
		}
		
		//now its time to generate sym1 and sym0 in order
		pushLocalSym(entity.name, 0, 0, SymSection.STT_FILE, SectHeader.SHN_ABS);
		pushLocalSym(null, 0, 0, STT_NOTYPE, SectHeader.SHN_UNDEF );
		
		return 0;
	}
	public SymEntry getSectionSym(Section sect){
		Iterator si = symbolList.iterator();
		while(si.hasNext()){
			SymEntry s = (SymEntry)si.next();
			if( (s.st_info&0xf) == STT_SECTION && s.st_shndx == sect.secno)
				return s;
		}
		return null;
	}

	public int link(){
		boolean endian = entity.isSEndian;
		
		size = symbolList.size() * getEntSize();
		data = new byte[size];
		int pos=0;
		Iterator si = symbolList.iterator();
		while(si.hasNext()){
			SymEntry sym = (SymEntry)si.next();	
			pos = Util.writeWord(data, pos, sym.st_name, endian);     
			pos = Util.writeWord(data, pos, sym.st_value.value(), endian);   
			pos = Util.writeWord(data, pos, sym.st_size, endian);
			pos = Util.writeByte(data, pos, sym.st_info);
			pos = Util.writeByte(data, pos, sym.st_other);
			pos = Util.writeShort(data, pos, sym.st_shndx, endian);
		}
		
		
		return 0;
	}

}
