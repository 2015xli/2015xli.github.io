package elf;

import java.util.LinkedList;
import java.util.Iterator;

public class SectionList {
	Entity entity;
	SectionList(Entity e){
		entity = e;
		sectList = new LinkedList();
		
		Section sect0 = new Section("", SectHeader.SHT_NULL);
		addSection(sect0);
		e.sects = this;
	}
	
	LinkedList sectList;
	
	public int parse(){
		byte[] buffer = entity.buffer;

		for(int i=1; i<entity.fhdr.e_shnum; i++){
			SectHeader shdr = entity.shdrs.shdr[i];
			int type = shdr.sh_type;
			int size = shdr.sh_size;
			
			Section stmp = null;
			if(type == SectHeader.SHT_STRTAB){
				stmp = new StrSection(entity);
				
			}else if(type == SectHeader.SHT_SYMTAB || 
					type == SectHeader.SHT_DYNSYM ){
				stmp = new SymSection(entity);
				
			}else if(type == SectHeader.SHT_REL){
				stmp = new RelSection(entity);
				
			}else{
				stmp = new Section(entity);
			}
			
			stmp.secno = i;	
			stmp.sh_type = type;
			sectList.add(stmp);

			if(type == SectHeader.SHT_NOBITS || size ==0 )
				continue;
			
			stmp.data = new byte[size];
			System.arraycopy(buffer, shdr.sh_offset, stmp.data, 0, size);
			
			stmp.specialize();
			
		}
		
		Iterator si = sectList.iterator();
		while(si.hasNext()){
			Section stmp = (Section)si.next();
			stmp.name = entity.getSectionNameString(stmp.secno);
		}
		
		return 0;
	}
	
	public int addSection(Section s){
		s.secno = sectList.size();
		sectList.add(s);
		
		s.entity = entity;
		
		return 0;
	}

	public int buildShstrtab(){
		//build the shstrtab content
		StrSection shstrtab = new StrSection(".shstrtab", SectHeader.SHT_STRTAB);
		addSection(shstrtab);
		
		Iterator si = sectList.iterator();
		while(si.hasNext()){
			Section sect = (Section)si.next();
			shstrtab.addString(sect.name);
		}
		
		shstrtab.buildIndex();
		
		entity.shstrtab = shstrtab;

		return 0;
	}

	public int link(){
		Iterator si = sectList.iterator();
		while(si.hasNext()){
			
			Section sect = (Section)si.next();
			sect.link();
			
		}		
		return 0;
	}
	
	public int serialize( ){

		Iterator si = sectList.iterator();
		while(si.hasNext()){
			
			Section sect = (Section)si.next();
			if(sect.sh_type == SectHeader.SHT_NOBITS || 
					sect.data == null)
				continue;
			
			sect.serialize();
			
		}
		return 0;
	}
}
