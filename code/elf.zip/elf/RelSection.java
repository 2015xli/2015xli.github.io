package elf;

import java.util.LinkedList;
import java.util.Iterator;

import java.io.PrintStream;

public class RelSection extends Section {

	LinkedList relList; //<RelEntry>
	
	SymSection symTab; //symtab describing symbols in rels, for linking sh_link
	Section appSect; //section (text or data) to apply the rels, for linking sh_info
	
	public static int RelEntrySize = 8; //we dont count addend into size when serialized
	
	class RelEntry{
		public int r_offset; //Elf32_Addr r_offset;
		public int r_info; 		 //Elf32_Word r_info;
		public int r_addend;
	}
	
	public static int R_386_NONE = 0; //none none           
	public static int R_386_32 = 1; //word32 S+A            
	public static int R_386_PC32 = 2; //word32 S+A-P        
	public static int R_386_GOT32 = 3; //word32 G + A       
	public static int R_386_PLT32 = 4; //word32 L + A - P   
	public static int R_386_COPY = 5; //none none           
	public static int R_386_GLOB_DAT = 6; //word32 S        
	public static int R_386_JMP_SLOT = 7; //word32 S        
	public static int R_386_RELATIVE = 8; //word32 B + A    
	public static int R_386_GOTOFF = 9; //word32 S + A - GOT
	public static int R_386_GOTPC = 10; //word32 GOT + A - P
	
	RelSection(Entity e){
		super(e);
	}
	
	RelSection(String s, int type, SymSection symtab, Section appliedSect){
		super(s, type);
		relList = new LinkedList();
		
		symTab = symtab;
		appSect = appliedSect;
	}
	
	public int specialize(){
		SectHeader shdr = entity.shdrs.shdr[secno];
		int entries = shdr.sh_size/shdr.sh_entsize;
		
		relList = new LinkedList();
		
		boolean endian = entity.isSEndian;
		int pos = 0;
		
		for(int j=0; j<entries; j++){
			RelEntry rtmp = new RelEntry();	
			rtmp.r_offset = Util.readWord(data, pos, endian); pos+=4; 
			rtmp.r_info = Util.readWord(data, pos, endian); pos+=4;
			relList.add(rtmp);
		}
		return 0;
	}
	
	public int dump(PrintStream out){
		
		out.println("\nRelocation Section: " + name);
		
		Iterator ri = relList.iterator();
		int j=0;
		while(ri.hasNext()){
			out.print("Rel " + j + " : ");
			RelEntry rtmp = (RelEntry)ri.next();
			SectHeader sechdr = entity.getSectHeader(secno);
			int symTabIndex = sechdr.sh_link;
			name = entity.getSymbolName(symTabIndex, rtmp.r_info>>8);
			if(name == null) name = " ";
			out.println(name);
			j++;
		}
		return 0;
	}
	
	public int getHeaderLink(){	return symTab.secno;}
	public int getHeaderInfo(){	return appSect.secno;}	
	public int getEntSize(){return RelEntrySize; }

	public int addRelocation(int offset, SymSection.SymEntry sym, int type){
		RelEntry rel = new RelEntry();
		rel.r_offset = offset;
		rel.r_info = (symTab.symIndex(sym) << 8) + (type & 0xf);
		relList.add(rel);
		return 0;
	}
	
	public int link(){
		boolean endian = entity.isSEndian;
		
		size = relList.size() * getEntSize();
		data = new byte[size];
		int pos=0;
		Iterator si = relList.iterator();
		while(si.hasNext()){
			RelEntry rel = (RelEntry)si.next();	
			pos = Util.writeWord(data, pos, rel.r_offset, endian);     
			pos = Util.writeWord(data, pos, rel.r_info, endian);   
		}
		
		return 0;
	}
}
