package elf;

import java.io.PrintStream;

public class Section{
	Entity entity;
	int	secno;
	
	String name;
	int sh_type;
	int sh_flags;
	
	byte[] data;
	int size;
	int offset;
	int align = 1; //default is no align requirement
	
	Section(Entity e){  //for parseing
		entity = e;
	}

	Section(String n, int stype){ //for linking
		name = n;
		sh_type = stype;
	}
	
	public int specialize(){ return 0;} 
	public int dump(PrintStream out){ return 0;} 
	
	///////////////////////////////Linking related//////////////////
	
	public int getHeaderFlags(){ return sh_flags; }
	public void setHeaderFlags(int f){ sh_flags = f; }
	public int getSectionSize(){ return size;}
	public void setSectionSize(int sz){ size = sz;}
	public int getSectionType(){ return sh_type;}
	public int getSectionOffset(){ return secno==0?0:offset;}
	public int getHeaderInfo(){	return 0; }
	public int getHeaderLink(){	return 0; }
	public int getHeaderAlign(){ return secno==0?0:align;}
	public void setHeaderAlign(int a){ align = a;}
	public int getEntSize(){return 0; }

	public int serialize(){
		SectHeader shdr = entity.shdrs.shdr[secno];
		
		int pos = entity.pos;
		int size = shdr.sh_size;

		entity.checkBufferSize(size);
		byte[] buffer = entity.buffer;
		
		System.arraycopy(data, 0, buffer, pos, size);
		
		entity.pos = pos+size;
		
		return 0;
	}
		
	public int link(){
		return 0;
	}
}
