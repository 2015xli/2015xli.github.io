package elf;

public class Address {
	int address;
	Address(int addr){
		address = addr;
	}
	void add(int offset){
		address += offset;
	}
	
	int value(){
		return address;
	}
	native static int dereference();
}
