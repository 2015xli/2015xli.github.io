package elf;

import java.io.PrintStream;

public class PrgHdrList {
	Entity entity;
	PrgHdrList(Entity e){
		entity = e;
	}
	boolean empty;

	public static int headerSize = 32;
	
	class ProgHeader {
		public int p_type; //Elf32_Word p_type;
		public int p_offset; //Elf32_Off p_offset;
		public Address p_vaddr; //Elf32_Addr p_vaddr;
		public Address p_paddr; //Elf32_Addr p_paddr;
		public int p_filesz; //Elf32_Word p_filesz;
		public int p_memsz; //Elf32_Word p_memsz;
		public int p_flags; //Elf32_Word p_flags;
		public int p_align; //Elf32_Word p_align;

	}

	ProgHeader[] phdr;
		
	public int parse(){
		if( entity.fhdr.e_phnum == 0){
			empty = true;
			return 1;
		}
		
		phdr = new ProgHeader[entity.fhdr.e_phnum];
		byte[] buffer = entity.buffer;
		entity.pos = entity.fhdr.e_phoff;
		boolean endian = entity.isSEndian;
		
		for(int i=0; i<entity.fhdr.e_phnum; i++){
			int pos = entity.pos;
			ProgHeader hdr = new ProgHeader();
			hdr.p_type = Util.readWord(buffer, pos, endian); pos+=4;
			hdr.p_offset = Util.readWord(buffer, pos, endian); pos+=4;
			int addr = Util.readWord(buffer, pos, endian); pos+=4;
			hdr.p_vaddr = new Address(addr);
			addr = Util.readWord(buffer, pos, endian); pos+=4;
			hdr.p_paddr = new Address(addr);
			hdr.p_filesz = Util.readWord(buffer, pos, endian); pos+=4;
			hdr.p_memsz = Util.readWord(buffer, pos, endian); pos+=4;
			hdr.p_flags = Util.readWord(buffer, pos, endian); pos+=4;
			hdr.p_align = Util.readWord(buffer, pos, endian); pos+=4;
			
			entity.pos = pos;
			phdr[i] = hdr;
		}
		return 0;
	}
	
	public void dump(PrintStream out){
		if(empty == true)
			out.println("No Program Header");
		else{
			out.println("Program Header dump not supported");
		}
		
		return;
	}
	
	public int link(){
		
		return 0;
	}
	
	public int serialize(){
	
		return 0;
	}
}
