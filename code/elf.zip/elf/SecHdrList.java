package elf;

import java.io.PrintStream;

public class SecHdrList {
	Entity entity;
	SecHdrList(Entity e){
		entity = e;
	}
		
	SectHeader[] shdr;
		
	public int parse(){
		
		if( entity.fhdr.e_shnum == 0){
			Util.error("No Section Header");
			return 1;
		}
		
		shdr = new SectHeader[entity.fhdr.e_shnum];
		entity.pos = entity.fhdr.e_shoff;
		
		for(int i=0; i<entity.fhdr.e_shnum; i++){
			SectHeader hdr = new SectHeader(entity);
			hdr.parse(i);			
			shdr[i] = hdr;
		}

		return 0;
	}
	
	public void dump(PrintStream out){
		out.println();
		out.println("Section headers");
		for(int i=0; i<entity.fhdr.e_shnum; i++){
			out.print("Section " + i + "  :  ");
			String name = entity.getSectionName(i);
			if(name == null) name = " ";
			out.println(name);
		}
	}
	public int link(){
		int sectCount = entity.getSectionCount();
		shdr = new SectHeader[sectCount];
		
		int offset = entity.fhdr.e_shoff + sectCount*SectHeader.headerSize;
		
		for(int i=0; i<sectCount; i++ ){
			Section sect = (Section)entity.sects.sectList.get(i);
			sect.offset = offset;
			SectHeader sechdr = new SectHeader(entity);
			sechdr.genHeader(sect);
			
			shdr[i] = sechdr;
			if(sect.sh_type != SectHeader.SHT_NOBITS )
				offset += sect.getSectionSize();
		}
		
		return 0;
	}
		
	public int serialize(){
		
		entity.pos = entity.fhdr.e_shoff;
		
		for(int i=0; i<entity.fhdr.e_shnum; i++){	
			shdr[i].serialize();
		}
		return 0;
	}
}
