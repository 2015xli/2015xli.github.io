package elf;

public class Loader {

	Entity load(String pathname){
		
		Entity entity = new Entity(pathname);
		entity.buffer = Util.loadFileintoBuffer(pathname);
		int res = entity.parse();
		
		if(res == -1) 
			return null;
		
		EntityPool.put(entity);
		
		return entity;
	}
}
