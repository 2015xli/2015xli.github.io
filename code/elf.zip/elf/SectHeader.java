package elf;

public class SectHeader{
	Entity entity;
	int secno;
	SectHeader(Entity e){
		entity = e;
	}
	public final static int SHT_NULL = 0;
	public final static int SHT_PROGBITS = 1;
	public final static int SHT_SYMTAB = 2;
	public final static int SHT_STRTAB = 3;
	public final static int SHT_RELA = 4;
	public final static int SHT_HASH = 5;
	public final static int SHT_DYNAMIC = 6;
	public final static int SHT_NOTE = 7;
	public final static int SHT_NOBITS = 8;
	public final static int SHT_REL = 9;
	public final static int SHT_SHLIB = 10;
	public final static int SHT_DYNSYM = 11;
	public final static int SHT_LOPROC = 0x70000000;
	public final static int SHT_HIPROC = 0x7fffffff;
	public final static int SHT_LOUSER = 0x80000000;
	public final static int SHT_HIUSER = 0xffffffff;
	
	public final static int SHN_UNDEF = 0;          
	public final static int SHN_LORESERVE = 0xff00; 
	public final static int SHN_LOPROC = 0xff00;    
	public final static int SHN_HIPROC = 0xff1f;    
	public final static int SHN_ABS = 0xfff1;       
	public final static int SHN_COMMON = 0xfff2;    
	public final static int SHN_HIRESERVE = 0xffff; 

	public final static int SHF_WRITE = 0x1;          
	public final static int SHF_ALLOC = 0x2;          
	public final static int SHF_EXECINSTR = 0x4;      
	public final static int SHF_MASKPROC = 0xf0000000;

	public int sh_name; //Elf32_Word sh_name;
	public int sh_type; //Elf32_Word sh_type;
	public int sh_flags; //Elf32_Word sh_flags;
	public Address sh_addr; //Elf32_Addr sh_addr;
	public int sh_offset; //Elf32_Off sh_offset;
	public int sh_size; //Elf32_Word sh_size;
	public int sh_link; //Elf32_Word sh_link;
	public int sh_info; //Elf32_Word sh_info;
	public int sh_addralign; //Elf32_Word sh_addralign;
	public int sh_entsize; //Elf32_Word sh_entsize;
	
	public static int headerSize = 40;
	
	public int parse(int sectIndex){
		byte[] buffer = entity.buffer;
		int pos = entity.pos;
		boolean endian = entity.isSEndian;
		
		sh_name = Util.readWord(buffer, pos, endian); pos+=4;     
		sh_type = Util.readWord(buffer, pos, endian); pos+=4;     
		sh_flags = Util.readWord(buffer, pos, endian); pos+=4;
		int addr = Util.readWord(buffer, pos, endian); pos+=4;     
		sh_addr = new Address(addr);
		sh_offset = Util.readWord(buffer, pos, endian); pos+=4; 
		sh_size = Util.readWord(buffer, pos, endian); pos+=4;     
		sh_link = Util.readWord(buffer, pos, endian); pos+=4;     
		sh_info = Util.readWord(buffer, pos, endian); pos+=4;     
		sh_addralign = Util.readWord(buffer, pos, endian); pos+=4;
		sh_entsize = Util.readWord(buffer, pos, endian); pos+=4;
		entity.pos = pos;
		secno = sectIndex;
		
		return 0;
	}
	
	public int genHeader(Section sect){

		StrSection strtab = entity.shstrtab;
		sh_name = strtab.indexString(sect.name);
		sh_type = sect.getSectionType();
		sh_flags = sect.getHeaderFlags();
		sh_addr = null;
		sh_offset = sect.getSectionOffset();
		sh_size = sect.getSectionSize();
		sh_link = sect.getHeaderLink();
		sh_info = sect.getHeaderInfo();
		sh_addralign = sect.getHeaderAlign();
		sh_entsize = sect.getEntSize();
			
		return 0;
	}
		
	public int serialize(){
		entity.checkBufferSize(headerSize);
		byte[] buffer = entity.buffer;

		int pos = entity.pos;
		boolean endian = entity.isSEndian;
		
		pos = Util.writeWord(buffer, pos, sh_name, endian);     
		pos = Util.writeWord(buffer, pos, sh_type, endian);     
		pos = Util.writeWord(buffer, pos, sh_flags, endian);    
		int addr = sh_addr==null? 0: sh_addr.value();                       
		pos = Util.writeWord(buffer, pos, addr, endian);        
		pos = Util.writeWord(buffer, pos, sh_offset, endian);   
		pos = Util.writeWord(buffer, pos, sh_size, endian);     
		pos = Util.writeWord(buffer, pos, sh_link, endian);     
		pos = Util.writeWord(buffer, pos, sh_info, endian);     
		pos = Util.writeWord(buffer, pos, sh_addralign, endian);
		pos = Util.writeWord(buffer, pos, sh_entsize, endian);  
		entity.pos = pos;
		
		return 0;
	}
	
}
