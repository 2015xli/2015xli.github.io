package elf;

import java.util.Hashtable;

public class EntityPool {
	private static Hashtable pool = new Hashtable();
	public static int put(Entity entity){
		pool.put(entity.name, entity);
		return 0;
	}
	public static Entity get(String name){
		return (Entity)pool.get(name);
	}
}
